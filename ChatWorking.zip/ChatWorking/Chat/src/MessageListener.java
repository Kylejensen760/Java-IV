public interface MessageListener {
	public void deliverMessage(Message message);
	public void removeMe();
}